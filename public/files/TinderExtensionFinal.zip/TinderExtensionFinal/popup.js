document.getElementById("saveButton").addEventListener("click", () => {
    const groqApiKey = document.getElementById("groqApiKey").value.trim();
    const status = document.getElementById("status");

    if (!groqApiKey) {
        status.textContent = "Error: Please enter a Groq API key";
        status.classList.add("error");
        return;
    }

    chrome.storage.sync.set({ GROQ_API_KEY: groqApiKey }, () => {
        status.textContent = "API key saved successfully!";
        status.classList.remove("error");
        setTimeout(() => { status.textContent = ""; }, 3000);
    });
});

chrome.storage.sync.get(["GROQ_API_KEY"], (keys) => {
    if (keys.GROQ_API_KEY) {
        document.getElementById("groqApiKey").value = keys.GROQ_API_KEY;
    }
});