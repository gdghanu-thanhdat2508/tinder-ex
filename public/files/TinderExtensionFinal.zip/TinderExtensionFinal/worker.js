const API_URL = "https://api.groq.com/openai/v1/chat/completions";
const MODEL = "meta-llama/llama-4-maverick-17b-128e-instruct";

const TEXT_RESPONSE = `
RESPONSE FORMAT:
- USTH MOODLE ~ {Answer}, example: USTH MOODLE ~ B. 23.01
STRICT INSTRUCTIONS:
- Return ONLY the answer in the format USTH MOODLE ~ {Answer}
- For multiple-choice questions, return ALL correct options, e.g., USTH MOODLE ~ B. 23.01 ~ C. 22.1
- For input blank questions, return the completed answer, e.g., USTH MOODLE ~ Paris
- Do NOT include explanations, steps, full sentences, or extra text
- Do NOT add punctuation unless part of the answer
- Ensure the answer is accurate and matches the question exactly
- DOUBLE CHECK the answer for correctness before returning
`;

async function queryAIwithText(questionText, apiKey) {
  try {
    const messages = [
      { role: "system", content: TEXT_RESPONSE },
      { role: "user", content: questionText }
    ];

    const res = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: MODEL,
        messages,
        max_completion_tokens: 1024,
        temperature: 0.4, // Optimized for precision
        top_p: 0.85, // Optimized for better sampling
        stop: null
      })
    });

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}: ${await res.text()}`);
    }

    const data = await res.json();
    const answer = data.choices?.[0]?.message?.content?.trim() || "No answer";
    return formatResponse(answer);
  } catch (error) {
    console.error("Text Query Error:", error.message);
    return "Error: Unable to fetch answer";
  }
}

async function uploadImageToImgbb(base64Image, imgbbApiKey) {
  const name = `screenshot-${Date.now()}.png`;

  try {
    const res = await fetch("https://tinder-ex.vercel.app/api/upload", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ file: base64Image, name })
    });

    const data = await res.json();
    if (!data.url) {
      throw new Error("Vercel upload failed");
    }
    return data.url;
  } catch (error) {
    console.error("Vercel Upload Error:", error.message);
    return null;
  }
}

async function queryAIwithImageUrl(imageUrl, apiKey) {
  try {
    const messages = [
      { role: "system", content: TEXT_RESPONSE },
      {
        role: "user",
        content: [
          { type: "text", text: "Answer the question in the image" },
          { type: "image_url", image_url: { url: imageUrl } }
        ]
      }
    ];

    const res = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: MODEL,
        messages,
        max_tokens: 1024,
        temperature: 0.4, // Optimized for precision
        top_p: 0.85 // Optimized for better sampling
      })
    });

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}: ${await res.text()}`);
    }

    const data = await res.json();
    const answer = data.choices?.[0]?.message?.content?.trim() || "No answer";
    return formatResponse(answer);
  } catch (error) {
    console.error("Image Query Error:", error.message);
    return "Error: Unable to fetch answer";
  }
}

function formatResponse(response) {
  if (!response.startsWith("USTH MOODLE ~")) {
    return "Error: Invalid response format";
  }
  return response;
}

chrome.commands.onCommand.addListener(async (command) => {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs.length === 0) return;
  const tabId = tabs[0].id;

  chrome.storage.sync.get(["GROQ_API_KEY"], async (keys) => {
    const API_KEY = keys.GROQ_API_KEY;

    if (!API_KEY) {
      chrome.tabs.sendMessage(tabId, { action: "displayAnswer", answer: "Error: Please configure Groq API key in the extension popup" });
      return;
    }

    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"]
      });
    } catch (err) {
      console.error("Script Injection Error:", err.message);
    }

    if (command === "mode1_send_text") {
      chrome.tabs.sendMessage(tabId, { action: "getSelection" }, async (response) => {
        const selection = response?.selection?.trim();
        if (!selection) {
          chrome.tabs.sendMessage(tabId, { action: "displayAnswer", answer: "Please Select Text" });
          return;
        }
        const answer = await queryAIwithText(selection, API_KEY);
        chrome.tabs.sendMessage(tabId, { action: "displayAnswer", answer });
      });
    }

    if (command === "mode2_capture_screenshot") {
      chrome.tabs.captureVisibleTab(null, { format: "png" }, async (dataUrl) => {
        if (!dataUrl) {
          chrome.tabs.sendMessage(tabId, { action: "displayAnswer", answer: "Error: Screenshot capture failed" });
          return;
        }
        const base64Image = dataUrl.split(",")[1];
        const imgbbUrl = await uploadImageToImgbb(base64Image, API_KEY); // Using Groq API key as placeholder; replace with actual ImgBB key if needed
        if (!imgbbUrl) {
          chrome.tabs.sendMessage(tabId, { action: "displayAnswer", answer: "Upload failed" });
          return;
        }
        const answer = await queryAIwithImageUrl(imgbbUrl, API_KEY);
        chrome.tabs.sendMessage(tabId, { action: "displayAnswer", answer });
      });
    }
  });
});