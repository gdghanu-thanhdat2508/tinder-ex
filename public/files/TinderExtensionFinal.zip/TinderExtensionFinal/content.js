let savedOriginalTitle = document.title;

function scrollTitleText(answer, interval = 200) {
  const fullText = ` Answer: ${answer} •`;
  let i = 0;
  const totalSteps = fullText.length;

  const intervalId = setInterval(() => {
    document.title = fullText.substring(i) + fullText.substring(0, i);
    i = (i + 1) % totalSteps;
  }, interval);

  const duration = totalSteps * interval;

  setTimeout(() => {
    clearInterval(intervalId);
    document.title = savedOriginalTitle;
  }, duration);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "getSelection") {
    let selection = window.getSelection().toString().trim();
    if (!selection) {
      const selectedNode = window.getSelection().anchorNode?.parentElement;
      selection = selectedNode?.innerText?.trim() || "";
    }
    sendResponse({ selection });
  }

  if (msg.action === "displayAnswer") {
    const answer = msg.answer.trim();

    if (answer.length <= 10 && !answer.includes(" ")) {
      document.title = `USTH Moodle Answer: ${answer}`;
      setTimeout(() => {
        document.title = savedOriginalTitle;
      }, 3000);
    } else {
      scrollTitleText(answer);
    }
  }
  return true;
});